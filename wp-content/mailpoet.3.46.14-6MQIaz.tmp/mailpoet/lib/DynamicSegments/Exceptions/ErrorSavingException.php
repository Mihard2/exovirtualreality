<?php

namespace MailPoet\DynamicSegments\Exceptions;

if (!defined('ABSPATH')) exit;


class ErrorSavingException extends \Exception {

}
